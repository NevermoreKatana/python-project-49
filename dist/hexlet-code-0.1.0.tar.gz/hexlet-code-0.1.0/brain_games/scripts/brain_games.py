def greeting(name: str):
    print(f'Welcome to the Brain Games, {name}!')

def main():
    greeting('Katana Nevermore')

if __name__ == '__main__':
    main()
    

