# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0', 'sympy>=1.12,<2.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-nod = brain_games.scripts.brain_nod:main',
                     'brain-prime = brain_games.scripts.brain_prime:main',
                     'brain-prog = brain_games.scripts.brain_prog:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/NevermoreKatana/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/NevermoreKatana/python-project-49/actions)\n<a href="https://codeclimate.com/github/NevermoreKatana/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/4517940bc5185bb713bc/maintainability" /></a>\n[![asciicast](https://asciinema.org/a/1jWbJf3CtATV6J83wMZ9yNtRr.svg)](https://asciinema.org/a/1jWbJf3CtATV6J83wMZ9yNtRr)\n\n[![asciicast](https://asciinema.org/a/1jWbJf3CtATV6J83wMZ9yNtRr.svg)](https://asciinema.org/a/nPyJQegmeADdVpjXUpqmQ3eSk)\n\n[![asciicast](https://asciinema.org/a/Hp2Y5GbePcktTveSaPyxCLXOK.svg)](https://asciinema.org/a/Hp2Y5GbePcktTveSaPyxCLXOK)\n\n[![asciicast](https://asciinema.org/a/Hp2Y5GbePcktTveSaPyxCLXOK.svg)](https://asciinema.org/a/eKs7SF06idIsbkV5dFJuJ56Hh)\n\n',
    'author': 'Katana Nevermore',
    'author_email': 'crymorebch@hmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
