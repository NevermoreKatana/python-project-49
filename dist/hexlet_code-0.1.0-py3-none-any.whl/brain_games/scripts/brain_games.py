from brain_games import cli
def greeting():
    print('Welcome to the Brain Games!')

def main():
    greeting()
    cli.welcome_user()

if __name__ == '__main__':
    main()
    